<?php
header('Content-type: text/html; charset=utf-8');
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <title>Multilingual Lexicon Creation for efficient Sentiment Analysis of social media Review Posted in Local Language</title>

    <link rel="stylesheet" type="text/css" href="style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="scripts/main.js"></script>
    <script src="scripts/classifier.js"></script>
  </head>
  <body class="loading" onload="myFunction()">
    <label id="loader">Loading...</label>
    <div id="loaded-content">
	<center style="padding-left: 100px; padding-right: 100px;"><br>
	<img style="height: 200px;; width:auto;" src="logo.png" alt="logo">
	<h1>Multilingual Lexicon Creation for Efficient Sentiment Analysis of Social Media Review Posted in Local Language</h1><br>
	<h3>Developed By Muhammad Sadiq </h3>
	</center>

	<form method="POST" action="">
      <div>
	  <input type="text" name="search" id="area-text" value="<?=@$_POST["search"];?>" placeholder="Search" dir="auto" autofocus required>		
	  <select name="lexicon" id="lexicon" required>
	<option value="English" <?php if(@$_POST["lexicon"]=="English") echo 'selected' ; ?>>English</option>
	<option value="roman_urdu" <?php if(@$_POST["lexicon"]=="roman_urdu") echo 'selected' ; ?>>Roman Urdu</option>
	<option value="roman_pashto" <?php if(@$_POST["lexicon"]=="roman_pashto") echo 'selected' ; ?>>Roman Pashto</option>
	<option value="pashto" <?php if(@$_POST["lexicon"]=="pashto") echo 'selected' ; ?>>Pashto</option>
	<option value="Urdu" <?php if(@$_POST["lexicon"]=="Urdu") echo 'selected' ; ?>>Urdu</option>
	</select>	  
	</div>
	<div>
	<br>
        <button type="submit" name="submit" id="rate-buttonn">Rate</button>
		</div>
	</form>
		
		
		<?php
$con = mysqli_connect('localhost','root','','multilingual_lexicon');
$con -> set_charset("utf8");
                     if(isset($_POST["submit"]))  
                     { 
$str = $_POST["search"];
$lex = $_POST["lexicon"];

if($lex !=='English'){


if ($lex == 'roman_urdu') {
$table = "urdu";
$roww = "Roman_Urdu";
}
elseif ($lex == 'Urdu'){
$table = "urdu";
$roww = "Urdu";
}
elseif ($lex == 'roman_pashto'){
$table = "pashto";
$roww = "Roman_Pashto";
}
elseif ($lex == 'pashto'){
$table = "pashto";
$roww = "Pashto";
}
 
                          $sql_query = "SELECT * FROM `".$table."` WHERE `".$roww."`='".$str."'";  
                          $result = mysqli_query($con, $sql_query);  
                          if(mysqli_num_rows($result) > 0)  
                          {  
                          $row = mysqli_fetch_array($result);  
                                
?>							  
 <textarea id="rate-text" autofocus hidden><?php
 echo "".@$row["English"].""; 
 ?></textarea> 
<script>
function myFunction() {
function explode(){
document.getElementById("rate-button").click();
}
setTimeout(explode, 2500);
}
</script>


<?php   
                          }  
                          else  
                          {  
                               echo '<label>Data not Found</label>';  
                          }
}
else{
?>
<textarea id="rate-text" autofocus hidden><?php
 echo "".@$str.""; 
 ?></textarea> 
<script>
function myFunction() {
function explode(){
document.getElementById("rate-button").click();
}
setTimeout(explode, 2500);
}
</script>

<?php 
}
}						  
                     ?>  
      </div>
        <button id="rate-button" hidden></button>
      </div>
      <div>
        <label id="rating" class="norating">Score -3</label>
      </div>
    </div>
  </body>

</html>

