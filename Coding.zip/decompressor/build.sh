rm decompressor.js*
gopherjs build -m
